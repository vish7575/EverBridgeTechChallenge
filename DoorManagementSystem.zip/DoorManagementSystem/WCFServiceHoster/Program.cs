﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFServiceHoster
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                using (System.ServiceModel.ServiceHost host = new
                     System.ServiceModel.ServiceHost(typeof(FacilityDoorManagement.FacilityDoorManagementService)))
                {
                    host.Open();
                    Console.WriteLine("Host started @ " + DateTime.Now.ToString());
                    Console.ReadLine();
                }
            }
            catch (Exception)
            {
                Console.Write("Unable to start service: Please Run App in Admin Mode");
            }
        }
    }
}

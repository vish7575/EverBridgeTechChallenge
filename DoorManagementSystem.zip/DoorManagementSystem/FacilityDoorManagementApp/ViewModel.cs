﻿using FacilityDoorManagementApp.FacilityDoorManagementServiceReference;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;

namespace FacilityDoorManagementApp
{
    class ViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<FacilityDoor> listOfDoors = new ObservableCollection<FacilityDoor>();
        private Model model = null;
        private readonly Command loadAllDoors;
        private readonly Command addNewDoor;
        private readonly Command removeDoor;
        private readonly Command saveChanges;

        public ObservableCollection<string> userOptions = new ObservableCollection<string> { "View Doors", "Control Doors", "Configure doors", };

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public ObservableCollection<FacilityDoor> ListOfDoorsInFacility
        {
            get { return listOfDoors; }
            set
            {
                listOfDoors = value;
                PropertyChanged(this, new PropertyChangedEventArgs("ListOfDoorsInFacility"));
            }
        }

        public ViewModel()
        {
            model = new Model();
            loadAllDoors = new Command(GetAllDoors);
            addNewDoor = new Command(AddNewDoor);
            removeDoor = new Command(DeleteDoor);
            saveChanges = new Command(SaveChanges);
        }

        #region Properties
        private FacilityDoor selectedItem = null;
        public FacilityDoor SelectedDoor
        {
            get
            {
                return selectedItem;
            }
            set
            {
                selectedItem = value;
                OnPropertyChanged("SelectedDoor");
            }
        }

        public ObservableCollection<string> ListOfUserOptions
        {
            get { return userOptions; }
            set
            {
                userOptions = value;
                PropertyChanged(this, new PropertyChangedEventArgs("ListOfUserOptions"));
            }
        }

        private string userOption = string.Empty;

        public string UserOptionSeleted
        {
            get
            {
                return userOption;
            }
            set
            {
                userOption = value;
                UpdateDataAndUIOptions(userOption);
                OnPropertyChanged("UserOptionSeleted");
            }
        }

        private bool enableLoadDoor = false;
        public bool EnableLoadDoors
        {
            get
            {
                return enableLoadDoor;
            }
            set
            {
                enableLoadDoor = value;
                OnPropertyChanged("EnableLoadDoors");
            }
        }

        private bool enableSaveChanges = false;
        public bool EnableSaveChanges
        {
            get
            {
                return enableSaveChanges;
            }
            set
            {
                enableSaveChanges = value;
                OnPropertyChanged("EnableSaveChanges");
            }
        }

        private bool enableAddRemoveDoor = false;
        public bool EnableAddRemoveDoors
        {
            get
            {
                return enableAddRemoveDoor;
            }
            set
            {
                enableAddRemoveDoor = value;
                OnPropertyChanged("EnableAddRemoveDoors");
            }
        }

        private bool allowModifications = false;
        public bool AllowModifications
        {
            get
            {
                return allowModifications;
            }
            set
            {
                allowModifications = value;
                UpdateUIElementsForEdits(allowModifications);
                OnPropertyChanged("AllowModifications");
            }
        }

        private string userInfoText = string.Empty;

        public string UserInfoText
        {
            get
            {
                return userInfoText;
            }
            set
            {
                userInfoText = value;
                OnPropertyChanged("UserInfoText");
            }
        }

        private void UpdateUIElementsForEdits(bool canAllowEdits)
        {
            foreach (var item in ListOfDoorsInFacility)
            {
                item.EnableEditCustomlable = canAllowEdits;
                item.EnableLockUnlock = canAllowEdits;
                item.EnableOpenClose = canAllowEdits;
            }
            CollectionViewSource.GetDefaultView(this.ListOfDoorsInFacility).Refresh();
        }

        #endregion

        /// <summary>
        /// Method to handle user options
        /// </summary>
        /// <param name="userOption"></param>
        private void UpdateDataAndUIOptions(string userOption)
        {
            if (string.IsNullOrEmpty(userOption))
            {
                return;
            }
            if (string.Compare(userOption, "view doors", true) == 0)
            {
                this.EnableLoadDoors = true;
                this.EnableAddRemoveDoors = false;
                this.EnableSaveChanges = false;
                this.AllowModifications = false;
                this.UserInfoText = "NOTE : (View Doors Mode), You can only view doors in this mode.";
            }
            else if (string.Compare(userOption, "control doors", true) == 0)
            {
                MessageBox.Show("Make sure you have required permissions..!", "Warning..!!");
                this.EnableLoadDoors = true;
                this.EnableAddRemoveDoors = false;
                this.EnableSaveChanges = true;
                this.AllowModifications = true;
                this.UserInfoText = "NOTE : (Control Doors Mode), You can control the existing doors.";
            }
            else
            {
                MessageBox.Show("Make sure you have required permissions..!", "Warning..!!");
                this.EnableLoadDoors = true;
                this.EnableLoadDoors = true;
                this.EnableAddRemoveDoors = true;
                this.EnableSaveChanges = true;
                this.AllowModifications = true;
                this.UserInfoText = "NOTE : (Configure Doors Mode), You have full access on doors.";
            }

            //Load doors available
            GetAllDoors();

        }

        /// <summary>
        /// This method will filter out only modified doors and save to server
        /// </summary>
        private void SaveChanges()
        {
            try
            {
                var modifiedDoors = ListOfDoorsInFacility.Where(x => x.IsModified == true)?.ToList();
                if (modifiedDoors.Count > 0)
                {
                    model.SaveChangesToDoors(GetServerTypeDataHelper(modifiedDoors));
                    GetAllDoors(); // Refresh after Save
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to save changes", "Error!!");
            }
        }

        /// <summary>
        /// This method does async calls to server to delete a particular door based on ID
        /// After which it will auto-refresh UI collection of Doors from server
        /// </summary>
        private async void DeleteDoor()
        {
            try
            {
                if (SelectedDoor != null)
                {
                    await Task.Run(() =>
                    {
                        model.RemoveDoor(SelectedDoor.ID);
                    });

                    GetAllDoors(); // Refresh after delete
                    this.EnableSaveChanges = false;

                }
                else
                {
                    MessageBox.Show("No Item Selected..!", "Warning..!!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Failed to delete the door", "Error!!");
            }
        }

        /// <summary>
        /// Method that inserts new door with defaults
        /// </summary>
        private void AddNewDoor()
        {
            ListOfDoorsInFacility.Add(new FacilityDoor
            {
                CustomLabel = "Default Lable",
                IsLocked = false,
                IsOpen = false,
                Name = "Default New",
                AllowEditingDoorName = true,
                IsModified = true,
                EnableOpenClose = true,
                EnableLockUnlock = true,
                EnableEditCustomlable = true,
            });
            this.EnableSaveChanges = true;
        }

        /// <summary>
        /// Method gets all doors available in facility and makes it available to client
        /// </summary>
        private async void GetAllDoors()
        {
            try
            {
                ListOfDoorsInFacility.Clear();
                List<Door> doorsFromServer = null;
                await Task.Run(() =>
                {
                    doorsFromServer = model.GetAllAvailableDoors();
                });
                DataHelperServerToClient(doorsFromServer);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to get doors info: " + ex.Message, "Error!!");
            }

        }

        private void DataHelperServerToClient(List<Door> ListOfDoorsInFacilityFromServer)
        {
            try
            {
                foreach (var item in ListOfDoorsInFacilityFromServer)
                {
                    ListOfDoorsInFacility.Add(
                        new FacilityDoor
                        {
                            ID = item.DoorID,
                            Name = item.DoorName,
                            CustomLabel = item.CustomLable,
                            IsLocked = item.IsLocked,
                            IsOpen = item.IsOpen,
                            AllowEditingDoorName = false,
                            IsModified = false,
                            EnableEditCustomlable = this.AllowModifications,
                            EnableLockUnlock = this.AllowModifications,
                            EnableOpenClose = this.AllowModifications
                        });
                }
            }
            catch (Exception)
            {
            }
        }

        private List<Door> GetServerTypeDataHelper(List<FacilityDoor> clientListOfModifiedDoors)
        {
            var serverList = new List<Door>();

            try
            {
                foreach (var item in clientListOfModifiedDoors)
                {
                    serverList.Add(new Door
                    {
                        DoorID = item.ID,
                        CustomLable = item.CustomLabel,
                        IsLocked = item.IsLocked,
                        IsOpen = item.IsOpen,
                        DoorName = item.Name,
                        ClientID = "1",        // Note: Will be improved with user/client login registration and New ClientTable. Door-Client Realtionship
                        ClientName = "Client"
                    });
                }
                return serverList;
            }
            catch (Exception)
            {
                MessageBox.Show("Failed to send Updates to server", "Error");
                return serverList;
            }
        }
    }
}

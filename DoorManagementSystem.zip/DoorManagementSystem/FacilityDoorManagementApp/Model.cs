﻿using FacilityDoorManagementApp.FacilityDoorManagementServiceReference;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FacilityDoorManagementApp
{
    class Model
    {
        DoorManagementServiceClient client;
        public Model()
        {
            try
            {
                client = new DoorManagementServiceClient();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to connect to server");
            }
        }

        public  List<Door> GetAllAvailableDoors()
        {
            try
            {
                return client.GetListOfAvailableDoors().ToList();
            }
            catch (Exception)
            {

                throw new Exception("Failed to connect to server");
            }
        }

        public void RemoveDoor(int doorID)
        {
            try
            {
                 client.RemoveDoor(doorID);
            }
            catch (Exception)
            {
                throw new Exception("Failed to perform RemoveDoor");
            }
        }


        internal void SaveChangesToDoors(List<Door> listOfDoorsInFacility)
        {
            try
            {
                client.SaveModificationsToDoors(listOfDoorsInFacility.ToArray());
            }
            catch (Exception)
            {
                throw new Exception("Failed to perform SaveChangesToDoors");
            }
        }

        internal void AddNewDoor(Door newDoor)
        {
            try
            {
                client.AddNewDoor(newDoor);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
